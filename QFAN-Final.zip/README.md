# QFAN Final — Quantum Field Access Network

Konsolidierte Final-Version aus:
- QFAN_v1.5 (QFAN-Network: Engine, UI, Vault, Ledger, Hub, Substrate)
- GitHub main (Shape-Check / `coerce_phase_vector` in `qfan_core`)

## Start

```bat
host\START_HOST.bat
client\START_CLIENT.bat
```

oder:

```bash
python run_host.py
python run_client.py
python -m qfan
```

## Struktur

```
qfan/
  qfan_core.py      Liouville + Shape-Guard (LOCKDOWN statt Crash)
  engine.py         Host/Client Feld-Engine
  substrates.py     Multi-Substrate-Bus (file / hub / adapter / ble)
  qdns.py field_dhcp.py qip.py field_burst.py field_sync.py
  vault.py ledger.py telemetry.py hub.py slotmailbox.py
  ui.py app.py main.py
client/ host/ docs/ tests/
```

## Tests

```bash
PYTHONPATH=. python tests/test_engine.py
PYTHONPATH=. python tests/test_hardware_substrates.py
PYTHONPATH=. python -m unittest tests.test_invalid_vectors -v
```

## Feldmodus

Steuerung: Phasenraum, Liouville (`det(J)≈1`), QDNS, Field-DHCP, QIP.
Substrate tragen Bytes — kein IP-Steuerpfad.
