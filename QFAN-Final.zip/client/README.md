# Client Browser

1. INSTALL.bat  2. START_CLIENT.bat
